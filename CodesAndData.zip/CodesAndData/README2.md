
Positional chance coincidence modelling software (Black_Hole_Distribution_v2.0.ipnb), and associated input data from BH and SNR catalogs (Corral_data_simplified.csv and Green_Catalog_SNRs.csv, respectively). See Maxted, Ruiter, Belczynski, Seitenzahl and Crocker, 2020 (???), Science, for details.  
